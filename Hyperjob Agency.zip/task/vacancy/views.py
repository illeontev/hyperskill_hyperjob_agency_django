from django.shortcuts import render
from django.views import View
from . import models
from django.shortcuts import redirect
from django.http import HttpResponse

class VacancyView(View):
    def get(self, request):
        return render(request, "vacancies.html",
                      {"vacancies": models.Vacancy.objects.all()})

    def post(self, request, *args, **kwargs):
        author = request.user
        if not author.is_staff:
            return HttpResponse(status=403)
        description = request.POST.get('description')
        vacancy = models.Vacancy.objects.create(author=author, description=description)
        vacancy.save()
        return redirect('/')