from django.urls import path
from .views import VacancyView


urlpatterns = [
    path('vacancies', VacancyView.as_view()),
    path('vacancy/new', VacancyView.as_view()),
]
