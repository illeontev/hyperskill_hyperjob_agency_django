from django.shortcuts import render
from django.views import View
from . import models
from django.shortcuts import redirect
from django.http import HttpResponse

class ResumeView(View):

    def get(self, request):
        return render(request, "resumes.html",
                      {"resumes": models.Resume.objects.all()})


    def post(self, request, *args, **kwargs):
        author = request.user
        if not author.is_authenticated:
            return HttpResponse(status=403)
        description = request.POST.get('description')
        resume = models.Resume.objects.create(author=author, description=description)
        resume.save()
        return redirect('/')