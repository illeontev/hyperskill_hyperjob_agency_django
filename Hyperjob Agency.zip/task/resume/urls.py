from django.urls import path
from .views import ResumeView


urlpatterns = [
    path('resumes', ResumeView.as_view()),
    path('resume/new', ResumeView.as_view()),
]
