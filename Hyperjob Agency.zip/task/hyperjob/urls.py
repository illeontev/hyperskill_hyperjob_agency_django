from django.urls import path, include
from .views import MainView, MySignupView, MyLoginView, HomeView
from django.views.generic.base import RedirectView

urlpatterns = [
    path('', MainView.as_view()),
    path('', include('vacancy.urls')),
    path('', include('resume.urls')),
    path('signup', MySignupView.as_view()),
    path('login', MyLoginView.as_view()),
    path('home', HomeView.as_view()),
    path('accounts/profile/', RedirectView.as_view(url='/login')),
    # path('vacancy/new', ''),
]